/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
*/

unsigned hash();
unsigned bighash();
void readdefaultstopwords();
void addstophash();
int isstopword();
void addtofilehashlist();
long getfilenum();
void addtofwordtotals();
int gettotalwords();
void mergeresulthashlist();
void initresulthashlist();
