/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
*/

char *lstrstr();
char *getword();
char *getconfvalue();
char *parsetitle();
char *mystrdup();
int iswordchar();
char *replace();
int wordcompare();
char *convertentities();
char *getent();
char *converttonamed();
int hasnumbered();
char *converttoascii();
int hasnonascii();
