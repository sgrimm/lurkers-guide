#! /usr/local/bin/perl
# Splits usenet archives by article

# pull in directories...

eval(`cat splitter.cf`) || die("Config file error!");


# NEARLY CONSTS

$COUNT=0;
$FIRST=0;
$DATE="";
$OLDDATE="";
$SUBJECT="";
$OLDSUBJECT="";
$BODY="";
$QUESTION="";

die("Please supply filename for splitter input\nUsage:  splitter  jms-95-01\nproduces files jms-95-01/nn.html") if ! $ARGV[0];

foreach(@ARGV) {
   ($FNAME) = m!/([^/]+)!;
   $FNAME= $_ if ! $FNAME;
   $NEWPATH= "$USENETDIR/$FNAME";
   mkdir($NEWPATH, oct("777"))  || 
      die ("Unable to create new directory $NEWPATH\n");

   open(INF, "< $_");
   while (<INF>) {
     # first skip to the first date

     s/\&/&amp;/g;
     s/\>/&gt;/g;
     s/\</&lt;/g;
     if (/^Date: ([0-9]+ [A-Za-z]+ [0-9]+)/) {
       $DATE= $1;
       next;
     }
     if (/^Subject: (.*)/) {
	$SUBJECT= $1;
	next;
     }

     next if ! $DATE;

     if ((/^From/)) {
	  if ($COUNT>0) {
	     print OUTFILE "</PRE>\n</BODY>\n</HTML>\n";
	     close OUTFILE;
	  }
	  $PREVFILE= "$COUNT.html" if $COUNT>0;
	  $COUNT++;
	  $NCOUNT= $COUNT + 1;
	  $NEXTFILE= "$NCOUNT.html";
	  $OLDDATE= $DATE;
	  $OLDSUBJECT= $SUBJECT;
	  open(OUTFILE, ">$NEWPATH/$COUNT.html");
	  $FIRST=1;
	  next;
     }
     if ($SUBJECT && $DATE && (/^ *$/)) {
	  if ($FIRST) {
	    print OUTFILE "<HTML>\n<HEAD>\n";
	    print OUTFILE "<TITLE>$SUBJECT ($DATE)</TITLE>\n";
	    print OUTFILE "</HEAD>\n<BODY>\n";
  	    print OUTFILE `cat $USENETBANNER`
	          if -r $USENETBANNER;
	  }
	  print OUTFILE "</PRE>\n" if (! $FIRST);
print OUTFILE "<A HREF=\"$PREVFILE\">Previous</A> " if $FIRST && $PREVFILE;
print OUTFILE "<A HREF=\"$NEXTFILE\">Next</A>\n<BR>\n" if $FIRST && $NEXTFILE;
	  print OUTFILE "<H2>$SUBJECT</H2>\n<PRE>";
	  print "\r $FNAME File number $COUNT $SUBJECT";     
	  $SUBJECT="";
	  $FIRST= 0;
	  next;
     }
     print OUTFILE $_;
  }
  close(OUTFILE);
  close(INF);
}
print "\r\nDone\r\n";

